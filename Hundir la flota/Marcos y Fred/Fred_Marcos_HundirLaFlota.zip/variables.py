from clases import *

# Estos serán los dos tableros con los que se jugará.
# Dos objetos de clase Tablero

user_tab = Tablero("Tablero del usuario",10,10)
machine_tab = Tablero("Machine_Boats",10,10)

# En estas dos listas se irán añadiendo los disparos del juego

user_lista = []
machine_lista = []

